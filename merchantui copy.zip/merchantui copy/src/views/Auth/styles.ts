import tw from 'tailwind-styled-components';

export const AuthContainer = tw.div`

`;

export const AuthForm = tw.form`
`;

export const FormHeader = tw.div`
`;

export const Title = tw.h3`
`;

export const Subtitle = tw.p`
`;
export const FormBody = tw.div`
`;

export const FormLink = tw.p`
    text-[#6231F4]
    text-center
    text-[14px]
    mt-5
    leading-[17px]
`;

export const FormGroup = tw.div` 
flex 
items-center
gap-5
 `;
