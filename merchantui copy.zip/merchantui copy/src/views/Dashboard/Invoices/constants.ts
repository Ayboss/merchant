import { HeadersPropsType } from '../../../components';

export const InvoiceHeader: Array<HeadersPropsType> = [
  {
    title: 'Invoice Id',
    responseMatch: 'invoiceid'
  },
  {
    title: 'Initiated on',
    responseMatch: 'initiatedon'
  },
  {
    title: 'Customer',
    responseMatch: 'customer'
  },
  {
    title: 'Total',
    responseMatch: 'total'
  },
  {
    title: 'Pay Status',
    responseMatch: 'paystatus'
  },
  {
    title: 'Link Url',
    responseMatch: 'linkurl'
  },
  {
    title: 'Due on ',
    responseMatch: 'dueon'
  },
  {
    title: '',
    responseMatch: 'status'
  },
  {
    title: 'Action',
    responseMatch: 'action'
  }
];
