import tw from 'tailwind-styled-components';

export const InvoiceContainer = tw.div`
    w-full
    relative
`;

export const TransactionsTopFlexWrapper = tw.div`
    flex
    justify-between
    w-full
    items-start
    mb-[22px]
`;

export const DashboardCardContainer = tw.div`
    flex
    gap-[20px]
`;

export const InvoiceTableTitleWithFilter = tw.div`
    w-full
    flex
    gap-4
    items-end
`;
