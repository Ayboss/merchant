import { useEffect, useMemo, useState } from 'react';
import Select from 'react-select';
import { SubmitHandler, useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
import { Button, CustomInput, Popup } from '../../../components';
import { useGetMerchantWalletBalanceQuery } from '../../../services/hooks/useGetMerchantWalletBalance';
import { useGetBanksQuery, useSendMoney, useVerifyBankAccount } from '../../../services/hooks';
import { PRIVATE_PATHS } from '../../../routes/paths';

interface FormValues {
  amount: string;
  accountNumber: string;
  narration: string;
  pin: string;
}

const CustomSelect = ({ placeholder, label, isloadingbanks, bankDataForSelect }: any) => {
  return (
    <div className='flex flex-1 flex-col relative'>
      <label className='text-[#6F7482] text-[10px] leading-normal tracking-[0.12px] font-medium'>
        {label}
      </label>
      <Select
        options={bankDataForSelect}
        classNamePrefix='Select Bank'
        placeholder={placeholder}
        // isLoading={isloadingbanks}
        isSearchable
        isClearable
        className='mt-[5px]'
        //   onChange={(val) =>
        //     setDetailsToVerify({
        //       ...detailsToVerify,
        //       // @ts-ignore not resolved val type
        //       bankName: val?.label,
        //       // @ts-ignore not resolved val type
        //       bankCode: val?.value
        //     })
        //   }
        required
      />
    </div>
  );
};
export const InvoiceCreatePopup = ({ onClose }: { onClose: () => void }) => {
  const [items, setItems] = useState([{ item: '', currency: '', quantity: '' }]);
  const { data: walletBalanceData, isLoading: walletBalanceLoading } =
    useGetMerchantWalletBalanceQuery();

  const { mutateAsync, isLoading, data: bankDetails } = useVerifyBankAccount();
  const { mutateAsync: sendMoneyAsync, isLoading: isMoneySending } = useSendMoney();

  const navigate = useNavigate();

  const { register, handleSubmit } = useForm<FormValues>();

  const [activeWallet, setActiveWallet] = useState<any>(null);

  const [detailsToVerify, setDetailsToVerify] = useState({
    accountNumber: '',
    bankName: '',
    bankCode: ''
  });

  const { data: banksData, isLoading: isLoadingBanks } = useGetBanksQuery();

  const bankDataForSelect = useMemo(() => {
    if (banksData?.data?.banks) {
      return banksData?.data?.banks.map((bankData: { bankName: any; bankCode: any }) => ({
        label: bankData?.bankName,
        value: bankData?.bankCode
      }));
    }
  }, [banksData]);

  const { accountNumber, bankName, bankCode } = detailsToVerify;

  useEffect(() => {
    if (bankName && accountNumber.length === 10) {
      mutateAsync({
        accountNumber,
        beneficiaryBank: bankCode
      })
        // eslint-disable-next-line no-console
        .then(() => toast.success('Account information verfied successfully'))
        .catch(() => toast.error('Could not verify bank details'));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountNumber, bankName]);

  const addmoreitems = () => {
    setItems([...items, { item: '', currency: '', quantity: '' }]);
  };
  const handleSubmitClick: SubmitHandler<FormValues> = (values) => {
    const { accountNumber, amount, narration, pin } = values;
    const { bankCode, bankName } = detailsToVerify;

    if (!activeWallet) {
      return toast.error('Please select a wallet to withdraw from');
    }

    if (pin.length < 4) {
      return toast.error('Please enter pin');
    }

    if (!bankDetails?.data?.accountName) {
      return toast.error('Beneficiary details not verified');
    }

    if (amount.length > 0 && bankCode) {
      sendMoneyAsync({
        beneficiaryAccountName: bankDetails?.data?.accountName,
        beneficiaryAccountNumber: accountNumber,
        beneficiaryBankName: bankName,
        beneficiaryBankCode: bankCode,
        sourceAccountNumber: activeWallet?.accountNumber,
        transactionAmount: amount,
        currencyCode: 'NGN',
        narration,
        reference: uuidv4(),
        pin
      })
        .then(() => {
          toast.success('Transaction completed successfully');
          onClose();
          navigate(PRIVATE_PATHS.PAYOUT_HISTORY);
        })
        .catch((error) => {
          if (Array.isArray(error?.response?.data?.errors)) {
            const errorMessages = error?.response?.data?.errors;

            errorMessages.forEach((error: any) =>
              toast.error(`${error?.fieldName} ${error?.message}`)
            );
          } else {
            toast.error(error?.response?.data?.responseMessage || error?.response?.data?.message);
          }
        });
    }
  };

  return (
    <Popup width={'800px'} title='Create New Invoice' onClose={onClose}>
      <div className='w-full relative'>
        <div className='w-full h-[2px] bg-[#F5F6FA] my-4' />

        <form onSubmit={handleSubmit(handleSubmitClick)} className='flex flex-col gap-[25px]'>
          <CustomInput
            {...register('amount', {
              required: true,
              pattern: /^[0-9]+$/
            })}
            placeholder='0.00'
            value='20242602'
            label='Invoice Number'
            className='w-full'
            InputClassName=' h-[40px]'
            disabled
          />
          <CustomInput
            placeholder='Enter a name for this invoice'
            label='Invoice Name'
            className='w-full'
            InputClassName=' h-[40px]'
            {...register('accountNumber', {
              required: true,
              pattern: /^[0-9]+$/,
              minLength: 10,
              maxLength: 10,
              onChange: (e) =>
                setDetailsToVerify({
                  ...detailsToVerify,
                  accountNumber: e.target.value
                })
            })}
          />
          <CustomInput
            placeholder='Enter Customer’s Name'
            label='Payer Name'
            className='w-full'
            InputClassName=' h-[40px]'
            {...register('accountNumber', {
              required: true,
              pattern: /^[0-9]+$/,
              minLength: 10,
              maxLength: 10,
              onChange: (e) =>
                setDetailsToVerify({
                  ...detailsToVerify,
                  accountNumber: e.target.value
                })
            })}
          />
          <div className='grid grid-cols-[7fr_3fr] gap-5'>
            <CustomInput
              placeholder='Enter a valid email'
              label='Payer Email'
              className='w-full'
              InputClassName=' h-[40px]'
              {...register('accountNumber', {
                required: true,
                pattern: /^[0-9]+$/,
                minLength: 10,
                maxLength: 10,
                onChange: (e) =>
                  setDetailsToVerify({
                    ...detailsToVerify,
                    accountNumber: e.target.value
                  })
              })}
            />
            <CustomInput
              placeholder='dd/mm/yyyy'
              label='Due Date'
              className='w-full'
              InputClassName=' h-[40px]'
              {...register('accountNumber', {
                required: true,
                pattern: /^[0-9]+$/,
                minLength: 10,
                maxLength: 10,
                onChange: (e) =>
                  setDetailsToVerify({
                    ...detailsToVerify,
                    accountNumber: e.target.value
                  })
              })}
            />
          </div>
          <div className='flex gap-5'>
            <CustomSelect
              placeholder='Select Billing Cycle'
              label='Frequency'
              isloadingbanks={isLoadingBanks}
              bankDataForSelect={bankDataForSelect}
            />
            <CustomSelect
              placeholder='Select Currency'
              label='Currency'
              isloadingbanks={isLoadingBanks}
              bankDataForSelect={bankDataForSelect}
            />
          </div>
          <div className='border p-5'>
            {items.map((item) => (
              <div className='grid grid-cols-[6fr_3fr_3fr] gap-5 border-b pb-4'>
                <CustomInput
                  placeholder='Enter Item Name'
                  label='Item'
                  InputClassName=' h-[40px]'
                  {...register('accountNumber', {
                    required: true,
                    pattern: /^[0-9]+$/,
                    minLength: 10,
                    maxLength: 10,
                    onChange: (e) =>
                      setDetailsToVerify({
                        ...detailsToVerify,
                        accountNumber: e.target.value
                      })
                  })}
                />
                <CustomSelect
                  placeholder='0.00'
                  label='Currency'
                  className='flex-1'
                  InputClassName=' h-[40px]'
                  {...register('accountNumber', {
                    required: true,
                    pattern: /^[0-9]+$/,
                    minLength: 10,
                    maxLength: 10,
                    onChange: (e) =>
                      setDetailsToVerify({
                        ...detailsToVerify,
                        accountNumber: e.target.value
                      })
                  })}
                />
                <CustomSelect
                  placeholder='0'
                  label='Quantity'
                  className='flex-1'
                  InputClassName=' h-[40px]'
                  {...register('accountNumber', {
                    required: true,
                    pattern: /^[0-9]+$/,
                    minLength: 10,
                    maxLength: 10,
                    onChange: (e) =>
                      setDetailsToVerify({
                        ...detailsToVerify,
                        accountNumber: e.target.value
                      })
                  })}
                />
              </div>
            ))}

            <Button
              isBusy={isMoneySending}
              type={'button'}
              name='Add More Items'
              disabled={walletBalanceData?.data?.length! < 1}
              className='bg-[#444444] w-[116px] h-[26px] text-[10px] font-medium'
              onClick={addmoreitems}
            />
          </div>

          {isLoading && <FontAwesomeIcon className='mt-[10px] mr-[auto]' icon={faSpinner} spin />}
          {bankDetails && (
            <p className='text-[#3EAF3F] text-[14px] font-medium'>
              {bankDetails?.data?.accountName}
            </p>
          )}

          <div className='flex w-full gap-5 mb-4'>
            <Button
              name='Cancel Action'
              type={'button'}
              onClick={onClose}
              className='bg-white border-solid rounded-[6px] text-[#EF4444] border-[#EF4444] border-[2px] w-[150px] h-[50px] font-medium'
            />
            <Button
              isBusy={isMoneySending}
              type={'submit'}
              name='Create Invoice'
              disabled={walletBalanceData?.data?.length! < 1}
              className=' w-[200px] h-[50px] font-medium'
            />
          </div>
        </form>
      </div>
    </Popup>
  );
};
