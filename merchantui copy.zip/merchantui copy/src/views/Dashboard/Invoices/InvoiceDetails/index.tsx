import { Button, EmptyContent, StatusTag } from '../../../../components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCopy,
  faPrint,
  faRocket,
  faRotateRight,
  faShirt,
  faXmark
} from '@fortawesome/free-solid-svg-icons';

import profile from '../../../../assets/img/manavatar.png';
import Navigation from '../../../../components/Navigation';

function InvoiceDetails() {
  const invoiceDetails = [
    { title: 'invoiceDetails', value: '#00123' },
    { title: 'Invoice Name', value: 'Plain T-shirts' },
    { title: 'Currency', value: 'NGN' },
    { title: 'Frequency', value: 'On-time' },
    { title: 'Payer Name', value: 'Mayowa Taiwo' },
    { title: 'Payer Email', value: 'mayowataiwo@gmail.com' },
    { title: 'Total Amount Due', value: '20 January 2024, 10:30:00' },
    { title: 'Due Date', value: '20 February 2024, 10:30:00' }
  ];
  return (
    <div className='w-full relative'>
      {/* LINK NAVIGATION */}
      <Navigation
        paths={[
          {
            title: 'Manage Invoices',
            link: '/invoices'
          },
          {
            title: 'Invoices Details',
            link: '/'
          }
        ]}
      />
      <div className='flex justify-between items-center'>
        <div className='flex gap-5'>
          <span className='text-[#444444] text-[25px] leading-none font-bold'>00100023</span>
          {/* active */}
          <StatusTag
            // @ts-ignore
            type={'Active'}
          />
        </div>
        <Button
          className='bg-[#F04949] w-[186px] rounded-[6px] h-10'
          //   onClick={handleLogOut}
          name={
            <span className=' text-[13px] flex items-center gap-[10px] justify-center  font-extrabold'>
              <FontAwesomeIcon icon={faXmark} style={{ color: '#ffffff' }} />
              Deactivate Invoice
            </span>
          }
        />
      </div>

      {/* TOP , EXPECTED AMOUNT, LINK */}
      <div className='border-t border-b flex pt-[10px] pb-[10px] mt-5 mb-5'>
        <div className='border-r pt-[10px] pb-[10px] pr-1 w-[216px]'>
          <span className='text-[10px] text-[#6F6C8F] '>Expected Amount</span>
          <p className='text-[#444444] text-[13px] font-semibold '>10,000.00 NGN</p>
        </div>
        <div className='border-r pt-[10px] pb-[10px] pr-1 pl-[10px] w-[216px]'>
          <span className='text-[10px] text-[#6F6C8F] '>Received Amount</span>
          <p className='text-[#444444] text-[13px] font-semibold '>10,000.00 NGN</p>
        </div>
        <div className=' pt-[10px] pb-[10px] pl-[10px] flex justify-between flex-1 items-center'>
          <div>
            <span className='text-[10px] text-[#6F6C8F] '>Invoice Link URL</span>
            <p className='text-[#444444] text-[13px] font-semibold w-[324px] whitespace-nowrap overflow-ellipsis overflow-hidden'>
              https://pou.com/pay?invoice_id=123456&amount=Product%OUnji1234BSwfD
            </p>
          </div>

          <div className='flex gap-[15px] '>
            <button className='h-10 w-10 rounded border border-[#6231F4] flex justify-center items-center'>
              <FontAwesomeIcon icon={faCopy} color='#6231F4' />
            </button>
            <button className='h-10 w-10 rounded border border-[#6231F4] flex justify-center items-center'>
              <FontAwesomeIcon icon={faPrint} color='#6231F4' />
            </button>
            <button className='h-10 w-10 rounded border border-[#6231F4] bg-[#6231F4] flex justify-center items-center'>
              <FontAwesomeIcon icon={faRocket} color='#fff' />
            </button>
          </div>
        </div>
      </div>

      {/* INVOICE DETAILS ,  ORDER SUMMARY */}

      <div className='grid grid-cols-2 gap-[30px]'>
        <div className='bg-white rounded-xl pb-5 shadow-custom-blue'>
          <div className='flex justify-between items-center border-b-2 border-[#F5F6FA]  pb-5 pt-7 pl-[30px] pr-[30px]'>
            <p className='text-[21px] text-[#444444] font-semibold '>Invoice Details</p>
            <StatusTag type='Pending' />
          </div>
          <div className='pl-[30px] pr-[30px] pt-5 pb-5'>
            {invoiceDetails.map((details) => (
              <div className='flex justify-between mb-[30px]' key={details.title}>
                <span className='text-[#6F6C8F] text-[13px] w-1/2 '>{details.title}</span>
                <span className='text-[#444444] text-[13px] w-1/2 text-right'>{details.value}</span>
              </div>
            ))}
          </div>
          {/* INVOICE DESCRIPTION */}
          <div className='pl-[30px] pr-[30px] pt-4 pb-4 bg-[#F5F6FA] '>
            <p className='text-[#6F7482] mb-[10px] text-[13px]'>Invoice Description</p>
            <p className=' text-[13px]'>
              Lodolor sit amet consectetur. Risus viverra adipiscing in suspendisse mi suspendisse.
              Velit fusce vulputate accumsan integer.
            </p>
          </div>
        </div>
        <div>
          <div className='bg-white rounded-xl pb-5 mb-10 shadow-custom-blue'>
            <div className='flex justify-between items-center border-b-2 border-[#F5F6FA]  pb-5 pt-7 pl-[30px] pr-[30px]'>
              <p className='text-[21px] text-[#444444] font-semibold '>Order Summary</p>
              <FontAwesomeIcon icon={faRotateRight} style={{ color: '#979797' }} />
            </div>

            <div className='pl-[30px] pr-[30px] pt-5 pb-5'>
              <div className='flex text-[13px] font-semibold text-[#444444] justify-between border-[#E4E4E7] border-b pb-[15px]'>
                <span className='flex-1'>Item Details</span>
                <span className='w-1/5 text-center'>Rate</span>
                <span className='w-1/5 text-center'>Qty</span>
                <span className='w-1/5 '>Amount</span>
              </div>
              {['_', '_', '_'].map(() => (
                <div className='flex justify-between text-[#444444] text-[13px]  border-[#E4E4E7] border-b pt-[6px] pb-[6px]'>
                  <p className='flex-1 flex items-center gap-[10px]'>
                    <FontAwesomeIcon icon={faShirt} color='#6231F4' />
                    <span>Plain Black T-shirts</span>
                  </p>
                  <span className='w-1/5 text-center'>₦2,000.00</span>
                  <span className='w-1/5 text-center'>x2</span>
                  <span className='w-1/5'>₦2,000.00</span>
                </div>
              ))}
            </div>
          </div>
          <div className='bg-white rounded-xl pb-5 shadow-custom-blue'>
            <div className='flex justify-between items-center border-b-2 border-[#F5F6FA]  pb-5 pt-7 pl-[30px] pr-[30px]'>
              <p className='text-[21px] text-[#444444] font-semibold '>Payment History</p>
              <FontAwesomeIcon icon={faRotateRight} style={{ color: '#979797' }} />
            </div>

            <div className='pl-[30px] pr-[30px] pt-5 pb-5'>
              {true ? (
                <>
                  <div className='flex font-semibold justify-between border-b-2 border-[#F5F6FA] text-[13px] pb-4'>
                    <span className=''>Recent Payments</span>
                    <span>Amount</span>
                  </div>
                  <div className='flex justify-between border-b-2 border-[#F5F6FA] text-[13px] pb-[10px] pt-[10px]'>
                    <div className='flex gap-1 items-center'>
                      {/* IMAGE */}
                      <img src={profile} className='w-[30px] h-[30px] rounded-full object-cover' />
                      <div className='flex flex-col gap-[2px]'>
                        <span className=''>Irikefe Anthony</span>
                        <span className='text-[10px]'>IrikefeAnthony@email.com</span>
                      </div>
                    </div>
                    <div className='flex flex-col items-end gap-[6px]'>
                      <span>+ ₦4,000.00</span>
                      <span className='text-[10px] text-[#6F6C8F]'>20 January 2024, 10:30:00</span>
                    </div>
                  </div>
                  <div className='flex justify-between border-b-2 border-[#F5F6FA] text-[13px] pb-[10px] pt-[10px]'>
                    <div className='flex gap-1 items-center'>
                      {/* IMAGE */}
                      <img src={profile} className='w-[30px] h-[30px] rounded-full object-cover' />
                      <div className='flex flex-col gap-[2px]'>
                        <span className=''>Irikefe Anthony</span>
                        <span className='text-[10px]'>IrikefeAnthony@email.com</span>
                      </div>
                    </div>
                    <div className='flex flex-col items-end gap-[6px]'>
                      <span>+ ₦4,000.00</span>
                      <span className='text-[10px] text-[#6F6C8F]'>20 January 2024, 10:30:00</span>
                    </div>
                  </div>
                </>
              ) : (
                <EmptyContent text='No payment has been made yet' />
              )}

              {/* EMPTY DIV */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default InvoiceDetails;
