import React, { useEffect, useRef, useState } from 'react';

import { useNavigate } from 'react-router-dom';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEllipsis } from '@fortawesome/free-solid-svg-icons';
import { SmallStatusTag } from '../../../components/SmallStatusTag';
import copy from '../../../assets/img/copy.png';

export const statusMap = {
  SUCCESSFUL: 'Completed',
  SUCCESS: 'Completed',
  Successful: 'Completed',
  PENDING: 'Pending',
  Pending: 'Pending',
  FAILED: 'FAILED',
  Failed: 'Failed',
  PROCESSING: 'PROCESSING',
  CREDIT: 'CREDIT',
  DEBIT: 'DEBIT',
  REVERSAL: 'REVERSAL'
};

type transformtype = {
  invoiceid: string;
  initiatedon: string;
  customer: string;
  total: string;
  linkurl: string;
  dueon: string;
  status: string;
};

export type HeadersPropsType = {
  title: string;
  responseMatch: string;
};

export interface TablePropsType {
  data: Array<transformtype>;
  length?: number;
  emptyLayout?: React.ReactNode;
  tableWrapperClassName?: string;
}

const MoreDropDown = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  const handleClickOutside = (event: any) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false); // Close the dropdown
    }
  };

  useEffect(() => {
    // Add click event listener
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      // Cleanup the event listener on component unmount
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div
      ref={dropdownRef}
      onClick={toggleDropdown}
      className='text-right w-full relative cursor-pointer'
    >
      <FontAwesomeIcon icon={faEllipsis} color='#A1A1AA' size='2x' />
      {isOpen && (
        <div className='absolute top-8 z-10 shadow-sm p-2 bg-white text-center right-0 w-24 '>
          <ul>
            <li
              className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'
              onClick={() => navigate('/invoices/details')}
            >
              View Invoice
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Edit
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Activate
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Deativate
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};

const headerstyle = {
  fontSize: '11px',
  color: '#6F7482',
  textTransform: 'uppercase',
  paddingTop: '10px',
  paddingBottom: '10px',
  fontWeight: '600'
};
const datastyle = {
  borderBottom: '1px solid #E4E4E7',
  color: '#444444',
  fontSize: '13px',
  fontWeight: '500',
  paddingTop: '19px',
  paddingBottom: '19px'
};
export const InvoiceTable = (props: TablePropsType) => {
  const { data } = props;

  return (
    <TableContainer>
      <Table sx={{ minWidth: 650 }} aria-label='simple table'>
        <TableHead>
          <TableRow className='border-t border-[#E4E4E7px]'>
            <TableCell sx={headerstyle}>Invoice Id</TableCell>
            <TableCell sx={headerstyle}>Initiated on</TableCell>
            <TableCell sx={headerstyle}>Customer</TableCell>
            <TableCell sx={headerstyle}>Total</TableCell>
            <TableCell sx={headerstyle}>Pay Status</TableCell>
            <TableCell sx={headerstyle}>Link Url</TableCell>
            <TableCell sx={headerstyle}>Due on</TableCell>
            <TableCell sx={headerstyle}></TableCell>
            <TableCell sx={headerstyle}>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((item) => (
            <TableRow
              key={item.invoiceid}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell sx={datastyle}>{item.invoiceid}</TableCell>
              <TableCell sx={datastyle}>{item.initiatedon}</TableCell>
              <TableCell sx={datastyle}>{item.customer}</TableCell>
              <TableCell sx={datastyle}>{item.total}</TableCell>
              <TableCell sx={datastyle}>
                <SmallStatusTag type='Pending' />
              </TableCell>
              <TableCell sx={datastyle}>
                <div className='flex items-center gap-2'>
                  <span className='w-[150px] font-medium overflow-hidden text-ellipsis text-[13px] whitespace-nowrap'>
                    {item.linkurl}
                  </span>
                  <img src={copy} className='w-[14px] h-[14px]' />
                </div>
              </TableCell>
              <TableCell sx={datastyle}>{item.dueon}</TableCell>
              <TableCell sx={datastyle}>
                <SmallStatusTag type='Active' />
              </TableCell>
              <TableCell sx={datastyle}>
                <MoreDropDown />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

// <div className={`${tableWrapperClassName ?? ''} rounded-[10px] table-wrapper`}>
// <div className='w-full overflow-scroll '>
//   <div className='w-full bg-white flex gap-[30px] border-[#E4E4E7] border-solid px-5 border-y-[1px]  py-[12px]'>
//     <div className={clsx(headerstyle, 'w-[80px]')}>Invoice Id</div>
//     <div className={clsx(headerstyle, 'w-[100px]')}>Initiated on</div>
//     <div className={clsx(headerstyle, 'w-[80px]')}>Customer</div>
//     <div className={clsx(headerstyle, 'w-[100px]')}>Total</div>
//     <div className={clsx(headerstyle, 'w-[80px]')}>Pay Status</div>
//     <div className={clsx(headerstyle, 'w-[180px]')}>Link Url</div>
//     <div className={clsx(headerstyle, 'w-[100px]')}>Due on</div>
//     <div className={clsx(headerstyle, 'w-[80px]')}></div>
//     <div className={clsx(headerstyle, 'w-[60px] text-right')}>Action</div>
//   </div>
//   <div className='w-full flex  flex-col bg-[#FFFFFF]'>
//     {data.length
//       ? data.map((item: transformtype, index) => {
//           return (
// <div
//   key={uuidv4()}
//   className='cursor-pointer flex items-center gap-[30px] px-5 py-5 border-b-[1px] border-[#E4E4E7] border-solid '
//   onClick={() => navigate('/invoices/details')}
// >
//   <div className={clsx(datastyle, 'w-[80px]')}>{item.invoiceid}</div>
//   <div className={clsx(datastyle, 'w-[100px]')}>{item.initiatedon}</div>
//   <div className={clsx(datastyle, 'w-[80px]')}>{item.customer}</div>
//   <div className={clsx(datastyle, 'w-[100px]')}>{item.total}</div>
//   <div className={clsx(datastyle, 'w-[80px]')}>
//     <SmallStatusTag type='Pending' />
//   </div>
//   <div className={clsx('text-[#444] flex gap-3 items-center', 'w-[180px]')}>
//     <span className='font-medium overflow-hidden text-ellipsis text-[13px] whitespace-nowrap'>
//       {item.linkurl}
//     </span>
//     <img src={copy} className='w-[14px] h-[14px]' />
//   </div>
//   <div className={clsx(datastyle, 'w-[100px]')}>{item.dueon}</div>
//   <div className={clsx(datastyle, 'w-[80px]')}>
//     <SmallStatusTag type='Active' />
//   </div>
//   <div
//     className={clsx(
//       'text-[#444] font-medium text-[13px] ',
//       'w-[60px] text-right relative'
//     )}
//   >
//     <MoreDropDown />
//   </div>
// </div>
//           );
//         })
//       : null}
//   </div>
// </div>
// {!data.length && emptyLayout}
// </div>
