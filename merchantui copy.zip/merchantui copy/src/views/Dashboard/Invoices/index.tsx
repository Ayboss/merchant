import { useState } from 'react';
import { Card, EmptyContent, LoaderControl, Paginator } from '../../../components';
import { TransactionsQueryParamsType, useGetTransactionsQuery } from '../../../services/hooks';
import { formatNumber } from '../../../utils';
import { CardType } from '../../../components/Card/type';
import { WhiteBGContainer } from '../Overview/components/ListContainer';
import { useDashboardTopIntro } from '../../../hooks/useDashboardTopIntro';
import { DashboardCardContainer, InvoiceContainer, InvoiceTableTitleWithFilter } from './styles';

import Searchinput from '../../../components/SearchInput';
import CustomDropdown from '../../../components/CustomDropdown';
import { InvoiceTable } from './InvoiceTable';

// const dropdownOption = [
//   { value: '', label: 'ALL' },
//   { value: 'SUCCESSFUL', label: 'COMPLETED' },
//   { value: 'PROCESSING', label: 'PROCESSING' },
//   { value: 'FAILED', label: 'FAILED' },
//   { value: 'REFUND', label: 'REFUND' }
// ];

// type transformtype = {
//   invoiceid: string;
//   initiatedon: string;
//   customer: string;
//   total: string;
//   linkurl: string;
//   dueon: string;
//   status: string;
// };

const transformData = [
  {
    invoiceid: '023242#',
    initiatedon: 'Jan 17, 2022',
    customer: 'NGN',
    total: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    dueon: 'Jan 17, 2022',
    status: 'active'
  },
  {
    invoiceid: '023242#',
    initiatedon: 'Jan 17, 2022',
    customer: 'NGN',
    total: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    dueon: 'Jan 17, 2022',
    status: 'active'
  },
  {
    invoiceid: '023242#',
    initiatedon: 'Jan 17, 2022',
    customer: 'NGN',
    total: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    dueon: 'Jan 17, 2022',
    status: 'active'
  },
  {
    invoiceid: '023242#',
    initiatedon: 'Jan 17, 2022',
    customer: 'NGN',
    total: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    dueon: 'Jan 17, 2022',
    status: 'active'
  },
  {
    invoiceid: '023242#',
    initiatedon: 'Jan 17, 2022',
    customer: 'NGN',
    total: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    dueon: 'Jan 17, 2022',
    status: 'active'
  }
];

const invoiceSummaryData: CardType[] = [
  {
    amount: 300,
    title: 'Total Created Invoices'
  },
  {
    amount: 10,
    title: 'Total Active Invoices'
  },
  {
    amount: `₦${formatNumber(2380485, 0)}`,
    title: 'Total Pending Invoices',
    rate: '-14%'
  },
  {
    amount: `₦${formatNumber(8450382, 0)}`,
    title: 'Total Paid Invoices',
    rate: '+36%'
  }
];

function Invoice() {
  const { TopIntro } = useDashboardTopIntro();

  const [query, setQuery] = useState<TransactionsQueryParamsType>({
    page: 0
  });
  const [currencyQuery, setCurrencyQuery] = useState({
    page: 1,
    reference: '',
    status: ''
  });
  const { data, refetch, isFetching } = useGetTransactionsQuery({ ...query });

  const handlePageChange = (current: number) => {
    setQuery({ ...query, page: current - 1 });
  };

  return (
    <InvoiceContainer>
      <TopIntro />
      <DashboardCardContainer>
        {invoiceSummaryData.map((detail) => (
          <Card key={detail.title} {...detail} />
        ))}
      </DashboardCardContainer>
      <WhiteBGContainer className='mt-5'>
        <h3 className='text-[#444] text-[16px] font-semibold leading-6 px-5 mb-[18px]'>
          Invoice History
        </h3>
        <InvoiceTableTitleWithFilter className='px-5 mb-[18px] py-0'>
          <Searchinput
            className='w-full max-w-[517px] mr-auto'
            placeholder='Search with Customer Name/Invoice ID'
            name='queryString'
            InputClassName=''
          />
          <CustomDropdown
            placeholder={'Currency'}
            dropdownOption={[
              { value: '', label: 'Currency' },
              { value: '', label: 'Currency' },
              { value: '', label: 'Currency' }
            ]}
            setCurrencyQuery={setCurrencyQuery}
            currencyQuery={currencyQuery}
          />
          <CustomDropdown
            placeholder={'Status'}
            dropdownOption={[
              { value: '', label: 'Status' },
              { value: '', label: 'Status' },
              { value: '', label: 'Status' }
            ]}
            setCurrencyQuery={setCurrencyQuery}
            currencyQuery={currencyQuery}
          />
          <CustomDropdown
            placeholder={'Date Range'}
            className='w-[167px]'
            dropdownOption={[
              { value: '', label: 'Date Range' },
              { value: '', label: 'Date Range' },
              { value: '', label: 'Date Range' }
            ]}
            setCurrencyQuery={setCurrencyQuery}
            currencyQuery={currencyQuery}
          />
        </InvoiceTableTitleWithFilter>

        <LoaderControl
          loading={false}
          // error={isError}
          overlay={isFetching}
          errorTitle='Something went wrong'
          errorSubTitle="Sorry, we couldn't load your Invoice, try reloading"
          minHeight={'400px'}
          errorControlOnClick={() => refetch()}
        >
          <InvoiceTable
            data={transformData}
            emptyLayout={
              <EmptyContent
                text='No recent invoives. Looks like you haven’t made any invoice, no worries! '
                onClick={() => refetch()}
                className='min-h-[400px]'
              />
            }
          />
        </LoaderControl>

        <Paginator
          total={data?.data?.totalElements || 1}
          pageSize={data?.data?.size || 1}
          onChange={handlePageChange}
        />
      </WhiteBGContainer>
    </InvoiceContainer>
  );
}

export default Invoice;
