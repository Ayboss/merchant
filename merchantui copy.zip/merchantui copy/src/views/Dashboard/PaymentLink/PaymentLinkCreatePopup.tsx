import { useEffect, useMemo, useState } from 'react';
import Select from 'react-select';
import { SubmitHandler, useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
import { Button, CustomInput, Popup } from '../../../components';
import { useGetMerchantWalletBalanceQuery } from '../../../services/hooks/useGetMerchantWalletBalance';
import { useGetBanksQuery, useSendMoney, useVerifyBankAccount } from '../../../services/hooks';
import { PRIVATE_PATHS } from '../../../routes/paths';

interface FormValues {
  amount: string;
  accountNumber: string;
  narration: string;
  pin: string;
}

const CustomSelect = ({ placeholder, label, bankDataForSelect }: any) => {
  return (
    <div className='flex flex-1 flex-col gap-[5px] relative'>
      <label className='text-[#6F7482] text-[10px] leading-normal tracking-[0.12px] font-medium'>
        {label}
      </label>
      <Select
        options={bankDataForSelect}
        classNamePrefix='Select Bank'
        className='h-[48px]'
        placeholder={placeholder}
        // isLoading={isloadingbanks}
        isSearchable
        isClearable
        // className='mt-2'
        //   onChange={(val) =>
        //     setDetailsToVerify({
        //       ...detailsToVerify,
        //       // @ts-ignore not resolved val type
        //       bankName: val?.label,
        //       // @ts-ignore not resolved val type
        //       bankCode: val?.value
        //     })
        //   }
        required
      />
    </div>
  );
};

const CustomTextbox = ({ label, placeholder }: any) => {
  return (
    <div className='flex flex-1 flex-col relative'>
      <label className='text-[#6F7482] mb-[5px] text-[10px] leading-normal tracking-[0.12px] font-medium'>
        {label}
      </label>
      <textarea
        placeholder={placeholder}
        className='h-[80px] rounded p-3 border-[#B8BCCA] border placeholder:text-[#B8BCCA] placeholder:text-[14px] placeholder:tracking-[0.14px] '
      />
      <span className='text-[#6F7482] text-[10px]'>0/150</span>
    </div>
  );
};
export const PaymentLinkCreatePopup = ({ onClose }: { onClose: () => void }) => {
  const { data: walletBalanceData } = useGetMerchantWalletBalanceQuery();

  const { mutateAsync, isLoading, data: bankDetails } = useVerifyBankAccount();
  const { mutateAsync: sendMoneyAsync, isLoading: isMoneySending } = useSendMoney();

  const navigate = useNavigate();

  const { register, handleSubmit } = useForm<FormValues>();

  // const [activeWallet, setActiveWallet] = useState<any>(null);
  const activeWallet: any = null;

  const [detailsToVerify, setDetailsToVerify] = useState({
    accountNumber: '',
    bankName: '',
    bankCode: ''
  });

  const { data: banksData, isLoading: isLoadingBanks } = useGetBanksQuery();

  const bankDataForSelect = useMemo(() => {
    if (banksData?.data?.banks) {
      return banksData?.data?.banks.map((bankData: { bankName: any; bankCode: any }) => ({
        label: bankData?.bankName,
        value: bankData?.bankCode
      }));
    }
  }, [banksData]);

  const { accountNumber, bankName, bankCode } = detailsToVerify;

  useEffect(() => {
    if (bankName && accountNumber.length === 10) {
      mutateAsync({
        accountNumber,
        beneficiaryBank: bankCode
      })
        // eslint-disable-next-line no-console
        .then(() => toast.success('Account information verfied successfully'))
        .catch(() => toast.error('Could not verify bank details'));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountNumber, bankName]);

  const handleSubmitClick: SubmitHandler<FormValues> = (values) => {
    const { accountNumber, amount, narration, pin } = values;
    const { bankCode, bankName } = detailsToVerify;

    if (!activeWallet) {
      return toast.error('Please select a wallet to withdraw from');
    }

    if (pin.length < 4) {
      return toast.error('Please enter pin');
    }

    if (!bankDetails?.data?.accountName) {
      return toast.error('Beneficiary details not verified');
    }

    if (amount.length > 0 && bankCode) {
      sendMoneyAsync({
        beneficiaryAccountName: bankDetails?.data?.accountName,
        beneficiaryAccountNumber: accountNumber,
        beneficiaryBankName: bankName,
        beneficiaryBankCode: bankCode,
        sourceAccountNumber: activeWallet?.accountNumber,
        transactionAmount: amount,
        currencyCode: 'NGN',
        narration,
        reference: uuidv4(),
        pin
      })
        .then(() => {
          toast.success('Transaction completed successfully');
          onClose();
          navigate(PRIVATE_PATHS.PAYOUT_HISTORY);
        })
        .catch((error) => {
          if (Array.isArray(error?.response?.data?.errors)) {
            const errorMessages = error?.response?.data?.errors;

            errorMessages.forEach((error: any) =>
              toast.error(`${error?.fieldName} ${error?.message}`)
            );
          } else {
            toast.error(error?.response?.data?.responseMessage || error?.response?.data?.message);
          }
        });
    }
  };

  return (
    <Popup width={'600px'} title='Create Payment Link' onClose={onClose}>
      <div className='w-full relative'>
        <div className='w-full h-[2px] bg-[#F5F6FA] my-4' />

        <form onSubmit={handleSubmit(handleSubmitClick)} className='flex flex-col gap-[25px]'>
          <CustomInput
            {...register('amount', {
              required: true,
              pattern: /^[0-9]+$/
            })}
            placeholder='Give your payment link a name'
            label='Link Name'
            className='w-full'
            InputClassName=' h-[40px]'
            disabled
          />
          <div className='flex gap-5'>
            <CustomSelect
              placeholder='Select Currency'
              label='Accepted Currency'
              isloadingbanks={isLoadingBanks}
              bankDataForSelect={bankDataForSelect}
            />
            <CustomInput
              placeholder='Enter Amount to recieve'
              label='Amount'
              className='flex-1'
              InputClassName=' h-[40px]'
              {...register('accountNumber', {
                required: true,
                pattern: /^[0-9]+$/,
                minLength: 10,
                maxLength: 10,
                onChange: (e) =>
                  setDetailsToVerify({
                    ...detailsToVerify,
                    accountNumber: e.target.value
                  })
              })}
            />
          </div>
          <div className='flex gap-5'>
            <CustomSelect
              placeholder='Select frequency'
              label='Payment frequency'
              isloadingbanks={isLoadingBanks}
              bankDataForSelect={bankDataForSelect}
            />
            <CustomInput
              placeholder='DD - MM - YYYY'
              label='Expires On'
              className='flex-1'
              InputClassName=' h-[40px]'
              {...register('accountNumber', {
                required: true,
                pattern: /^[0-9]+$/,
                minLength: 10,
                maxLength: 10,
                onChange: (e) =>
                  setDetailsToVerify({
                    ...detailsToVerify,
                    accountNumber: e.target.value
                  })
              })}
            />
          </div>
          <CustomSelect
            placeholder='Select who to bill'
            label='Who bears the transaction cost?'
            isloadingbanks={isLoadingBanks}
            bankDataForSelect={bankDataForSelect}
          />
          <CustomTextbox
            placeholder='Briefly describe what this link is for'
            label='Description'
            {...register('accountNumber', {
              required: true,
              pattern: /^[0-9]+$/,
              minLength: 10,
              maxLength: 10,
              onChange: (e) =>
                setDetailsToVerify({
                  ...detailsToVerify,
                  accountNumber: e.target.value
                })
            })}
          />

          <CustomTextbox
            placeholder='Briefly describe what this link is for'
            label='Success Message'
            {...register('accountNumber', {
              required: true,
              pattern: /^[0-9]+$/,
              minLength: 10,
              maxLength: 10,
              onChange: (e) =>
                setDetailsToVerify({
                  ...detailsToVerify,
                  accountNumber: e.target.value
                })
            })}
          />

          {isLoading && <FontAwesomeIcon className='mt-[10px] mr-[auto]' icon={faSpinner} spin />}
          {bankDetails && (
            <p className='text-[#3EAF3F] text-[14px] font-medium'>
              {bankDetails?.data?.accountName}
            </p>
          )}

          <div className='flex w-full gap-5 mb-4'>
            <Button
              isBusy={isMoneySending}
              type={'submit'}
              name='Create Payment Link'
              disabled={walletBalanceData?.data?.length! < 1}
              className=' w-[200px] h-[50px] font-medium'
            />
            <Button
              name='Cancel Action'
              type={'button'}
              onClick={onClose}
              className='bg-white border-solid rounded-[6px] text-[#EF4444] border-[#EF4444] border-[2px] w-[150px] h-[50px] font-medium'
            />
          </div>
        </form>
      </div>
    </Popup>
  );
};
