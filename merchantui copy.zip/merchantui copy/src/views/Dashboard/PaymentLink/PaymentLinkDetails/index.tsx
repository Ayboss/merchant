import { EmptyContent, StatusTag } from '../../../../components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCopy, faRocket, faRotateRight } from '@fortawesome/free-solid-svg-icons';
import profile from '../../../../assets/img/manavatar.png';
import Navigation from '../../../../components/Navigation';

function PaymentLinkDetails() {
  const paymentdetails = [
    { title: 'Link Name', value: 'Invoice #00123' },
    { title: 'ID', value: '123456XyZ' },
    { title: 'Currency', value: 'NGN' },
    { title: 'Frequency', value: 'On-time' },
    { title: 'Channel', value: '-' },
    { title: 'Paid On', value: '-' },
    { title: 'Settled On', value: '-' },
    { title: 'Created On', value: '20 February 2024, 10:30:00' },
    { title: 'Expires On', value: '20 February 2024, 10:30:00' }
  ];
  return (
    <div className='w-full relative'>
      <Navigation
        paths={[
          {
            title: 'Payment Links',
            link: '/payment-links'
          },
          {
            title: 'Details',
            link: '/'
          }
        ]}
      />
      <div className='flex justify-between items-center'>
        <div className='text-[#444444] text-[25px] leading-none font-bold'>
          <span>Link ID #00123</span>
        </div>
        {/* active */}
        <StatusTag
          // @ts-ignore
          type={'Active'}
        />
      </div>

      {/* TOP , EXPECTED AMOUNT, LINK */}
      <div className='border-t border-b flex pt-[10px] pb-[10px] mt-5 mb-5'>
        <div className='border-r pt-[10px] pb-[10px] pr-1 w-[216px]'>
          <span className='text-[10px] text-[#6F6C8F] '>Expected Amount</span>
          <p className='text-[#444444] text-[13px] font-semibold '>10,000.00 NGN</p>
        </div>

        <div className=' pt-[10px] pb-[10px] pl-[10px] flex justify-between flex-1 items-center'>
          <div>
            <span className='text-[10px] text-[#6F6C8F] '>Invoice Link URL</span>
            <p className='text-[#444444] text-[13px] font-semibold '>
              https://pou.com/pay?invoice_id=123456&amount=Product%OUnji1234BSwfD
            </p>
          </div>
          <div className='flex gap-[15px] '>
            <div className='flex gap-[15px] '>
              <button className='h-10 w-10 rounded border border-[#6231F4] flex justify-center items-center'>
                <FontAwesomeIcon icon={faCopy} color='#6231F4' />
              </button>

              <button className='h-10 w-10 rounded border border-[#6231F4] bg-[#6231F4] flex justify-center items-center'>
                <FontAwesomeIcon icon={faRocket} color='#fff' />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* INVOICE DETAILS ,  ORDER SUMMARY */}

      <div className='grid grid-cols-2 gap-[30px]'>
        <div className='bg-white rounded-xl pb-5 shadow-custom-blue'>
          <div className='flex justify-between items-center border-b-2 border-[#F5F6FA]  pb-5 pt-7 pl-[30px] pr-[30px]'>
            <p className='text-[21px] text-[#444444] font-semibold '>Transaction Details</p>
            <StatusTag type='Pending' />
          </div>
          <div className='pl-[30px] pr-[30px] pt-5 pb-5'>
            {paymentdetails.map((details) => (
              <div className='flex justify-between mb-[30px]' key={details.title}>
                <span className='text-[#6F6C8F] text-[13px] w-1/2 '>{details.title}</span>
                <span className='text-[#444444] text-[13px] w-1/2 text-right'>{details.value}</span>
              </div>
            ))}
          </div>
          {/* INVOICE DESCRIPTION */}
          <div className='pl-[30px] pr-[30px] pt-4 pb-4 bg-[#F5F6FA] '>
            <p className='text-[#6F7482] mb-[10px] text-[13px]'>Description</p>
            <p className=' text-[13px]'>
              Lodolor sit amet consectetur. Risus viverra adipiscing in suspendisse mi suspendisse.
              Velit fusce vulputate accumsan integer.
            </p>
          </div>
        </div>
        <div>
          <div className='bg-white rounded-xl pb-5 shadow-custom-blue'>
            <div className='flex justify-between items-center border-b-2 border-[#F5F6FA]  pb-5 pt-7 pl-[30px] pr-[30px]'>
              <p className='text-[21px] text-[#444444] font-semibold '>Recent Payments</p>
              <FontAwesomeIcon icon={faRotateRight} style={{ color: '#979797' }} />
            </div>

            <div className='pl-[30px] pr-[30px] pt-5 pb-5'>
              {true ? (
                <>
                  <div className='flex font-semibold justify-between border-b-2 border-[#F5F6FA] text-[13px] pb-4'>
                    <span className=''>Recent Payments</span>
                    <span>Amount</span>
                  </div>
                  <div className='flex justify-between items-center border-b-2 border-[#F5F6FA] text-[13px] pb-[10px] pt-[10px]'>
                    <div className='flex gap-1 items-center'>
                      {/* IMAGE */}
                      <img src={profile} className='w-[30px] h-[30px] rounded-full object-cover' />
                      <div className='flex flex-col gap-[2px]'>
                        <span className=''>Irikefe Anthony</span>
                        <span className='text-[10px]'>IrikefeAnthony@email.com</span>
                      </div>
                    </div>
                    <div className='flex flex-col items-end gap-[6px]'>
                      <span className='text-[10px] text-[#444444]'>+ ₦400,000.00</span>
                    </div>
                  </div>
                  <div className='flex justify-between items-center border-b-2 border-[#F5F6FA] text-[13px] pb-[10px] pt-[10px]'>
                    <div className='flex gap-1 items-center'>
                      {/* IMAGE */}
                      <img src={profile} className='w-[30px] h-[30px] rounded-full object-cover' />
                      <div className='flex flex-col gap-[2px]'>
                        <span className=''>Irikefe Anthony</span>
                        <span className='text-[10px]'>IrikefeAnthony@email.com</span>
                      </div>
                    </div>
                    <div className='flex flex-col items-end gap-[6px]'>
                      <span className='text-[10px] text-[#444444]'>+ ₦400,000.00</span>
                    </div>
                  </div>
                </>
              ) : (
                <EmptyContent text='No payment has been made yet' />
              )}

              {/* EMPTY DIV */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PaymentLinkDetails;
