import { HeadersPropsType } from '../../../components';

export const PaymenteHeader: Array<HeadersPropsType> = [
  {
    title: '',
    responseMatch: 'check'
  },
  {
    title: 'Link Name',
    responseMatch: 'linkname'
  },
  {
    title: 'Amount',
    responseMatch: 'amount'
  },
  {
    title: 'Currency',
    responseMatch: 'currency'
  },
  {
    title: 'Create On',
    responseMatch: 'createdon'
  },
  {
    title: 'Link Url',
    responseMatch: 'linkurl'
  },
  {
    title: '',
    responseMatch: 'copy'
  },
  {
    title: 'Action',
    responseMatch: 'action'
  }
];
