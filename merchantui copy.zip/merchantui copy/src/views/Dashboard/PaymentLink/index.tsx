import { useState } from 'react';
import { EmptyContent, LoaderControl, Paginator } from '../../../components';
import { TransactionsQueryParamsType, useGetTransactionsQuery } from '../../../services/hooks';

import { WhiteBGContainer } from '../Overview/components/ListContainer';
import { useDashboardTopIntro } from '../../../hooks/useDashboardTopIntro';

import { InvoiceContainer, InvoiceTableTitleWithFilter } from './styles';
// import { TransactionItem } from './components';

import Searchinput from '../../../components/SearchInput';
import { Paylinktable } from './Paylinktable';

const transformData = [
  {
    invoiceid: '023241',
    currency: 'NGN',
    amount: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    createdon: 'Jan 17, 2022'
  },
  {
    invoiceid: '023242',
    currency: 'NGN',
    amount: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    createdon: 'Jan 17, 2022'
  },
  {
    invoiceid: '023243',
    currency: 'NGN',
    amount: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    createdon: 'Jan 17, 2022'
  },
  {
    invoiceid: '023244',
    currency: 'NGN',
    amount: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    createdon: 'Jan 17, 2022'
  },
  {
    invoiceid: '023245',
    currency: 'NGN',
    amount: '#5,2000',
    linkurl:
      'https://pou.com/pay?invoice_id=123456&amount=50.00&currency=USD&description=Product%20Purchase',
    createdon: 'Jan 17, 2022'
  }
];

function PaymentLink() {
  const { TopIntro } = useDashboardTopIntro();

  const [query, setQuery] = useState<TransactionsQueryParamsType>({
    page: 0
  });

  const { data, refetch, isFetching } = useGetTransactionsQuery({ ...query });

  const handlePageChange = (current: number) => {
    setQuery({ ...query, page: current - 1 });
  };

  return (
    <InvoiceContainer>
      <TopIntro />

      <WhiteBGContainer className='mt-5'>
        <h3 className='text-[#444] text-[16px] font-semibold leading-6 px-5 mb-[18px]'>
          Payment Links
        </h3>
        <InvoiceTableTitleWithFilter className='px-5 mb-[18px] py-0'>
          <Searchinput
            className='w-full max-w-[517px] mr-auto'
            placeholder='Search with Customer Name/Invoice ID'
            name='queryString'
            InputClassName=''
          />
        </InvoiceTableTitleWithFilter>
        <LoaderControl
          loading={false}
          // error={isError}
          overlay={isFetching}
          errorTitle='Something went wrong'
          errorSubTitle="Sorry, we couldn't load your Invoice, try reloading"
          minHeight={'400px'}
          errorControlOnClick={() => refetch()}
        >
          <Paylinktable
            data={transformData}
            emptyLayout={
              <EmptyContent
                text='No recent invoives. Looks like you haven’t made any invoice, no worries! '
                onClick={() => refetch()}
                className='min-h-[400px]'
              />
            }
          />
        </LoaderControl>
        <Paginator
          total={data?.data?.totalElements || 1}
          pageSize={data?.data?.size || 1}
          onChange={handlePageChange}
        />
        {/* {!isError && (
          <Paginator
            total={data?.data?.totalElements || 1}
            pageSize={data?.data?.size || 1}
            onChange={handlePageChange}
          />
        )} */}
      </WhiteBGContainer>
    </InvoiceContainer>
  );
}

export default PaymentLink;
