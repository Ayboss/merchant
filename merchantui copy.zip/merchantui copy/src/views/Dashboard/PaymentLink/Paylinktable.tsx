import React, { useEffect, useRef, useState } from 'react';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import { useNavigate } from 'react-router-dom';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck, faEllipsis } from '@fortawesome/free-solid-svg-icons';
import copy from '../../../assets/img/copy.png';

export const statusMap = {
  SUCCESSFUL: 'Completed',
  SUCCESS: 'Completed',
  Successful: 'Completed',
  PENDING: 'Pending',
  Pending: 'Pending',
  FAILED: 'FAILED',
  Failed: 'Failed',
  PROCESSING: 'PROCESSING',
  CREDIT: 'CREDIT',
  DEBIT: 'DEBIT',
  REVERSAL: 'REVERSAL'
};

type transformtype = {
  invoiceid: string;
  currency: string;
  amount: string;
  linkurl: string;
  createdon: string;
};

export type HeadersPropsType = {
  title: string;
  responseMatch: string;
};

// export interface TablePropsType {
//   data: Array<transformtype>;
//   length?: number;
//   emptyLayout?: React.ReactNode;
//   tableWrapperClassName?: string;
// }

export interface TablePropsType {
  data: Array<transformtype>;
  emptyLayout?: React.ReactNode;
}

const MoreDropDown = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  const handleClickOutside = (event: any) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false); // Close the dropdown
    }
  };

  useEffect(() => {
    // Add click event listener
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      // Cleanup the event listener on component unmount
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div ref={dropdownRef} onClick={toggleDropdown} className=' w-full relative cursor-pointer'>
      <FontAwesomeIcon icon={faEllipsis} color='#A1A1AA' size='2x' />
      {isOpen && (
        <div className='absolute top-8 z-10 shadow-sm p-2 bg-white text-center right-0 w-28 '>
          <ul>
            <li
              className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'
              onClick={() => navigate('/payment-links/details')}
            >
              View Payment
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Edit
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Activate
            </li>
            <li className='font-medium text-[13px] text-right py-2 cursor-pointer transition duration-100 hover:bg-slate-200'>
              Deativate
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};

const headerstyle = {
  fontSize: '11px',
  color: '#6F7482',
  textTransform: 'uppercase',
  paddingTop: '10px',
  paddingBottom: '10px',
  fontWeight: '600'
};
const datastyle = {
  borderBottom: '1px solid #E4E4E7',
  color: '#444444',
  fontSize: '13px',
  fontWeight: '500',
  paddingTop: '14px',
  paddingBottom: '14px'
};

export const Paylinktable = (props: TablePropsType) => {
  const [selectedrow, setSelectedRow] = useState<string[]>([]);
  const { data } = props;
  // const navigate = useNavigate();

  const toggleSelected = (invoiceid: string) => {
    const id = selectedrow.findIndex((val) => val === invoiceid);

    if (id === -1) {
      setSelectedRow([...selectedrow, invoiceid]);
      return;
    }
    const newArr = [...selectedrow.slice(0, id), ...selectedrow.slice(id + 1)];
    setSelectedRow(newArr);
  };
  return (
    <TableContainer>
      <Table sx={{ minWidth: 650 }} aria-label='simple table'>
        <TableHead>
          <TableRow className='border-t border-[#E4E4E7px]'>
            <TableCell sx={headerstyle}>
              {' '}
              <div className='w-[20px] h-[20px] rounded-md border-[#D0D5DD] border '> </div>
            </TableCell>
            <TableCell sx={headerstyle}> Link Name</TableCell>
            <TableCell sx={headerstyle}>Amount</TableCell>
            <TableCell sx={headerstyle}>Currency</TableCell>
            <TableCell sx={headerstyle}>Created ON</TableCell>
            <TableCell sx={headerstyle}>Link Url</TableCell>
            <TableCell sx={headerstyle}>ACTION</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((item) => {
            const checked = selectedrow.findIndex((val) => val === item.invoiceid) >= 0;

            return (
              <TableRow
                key={item.invoiceid}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell sx={datastyle}>
                  <div
                    className='w-[20px] h-[20px] rounded-md border-[#D0D5DD] border grid place-content-center cursor-pointer'
                    onClick={() => toggleSelected(item.invoiceid)}
                  >
                    {checked && <FontAwesomeIcon icon={faCheck} color='#6231F4' />}
                  </div>
                </TableCell>
                <TableCell sx={datastyle}>{item.invoiceid}</TableCell>
                <TableCell sx={datastyle}>{item.amount}</TableCell>
                <TableCell sx={datastyle}>{item.currency}</TableCell>
                <TableCell sx={datastyle}>{item.createdon}</TableCell>
                <TableCell sx={datastyle}>
                  <div className='flex items-center gap-2'>
                    <span className='w-[150px] font-medium overflow-hidden text-ellipsis text-[13px] whitespace-nowrap'>
                      {item.linkurl}
                    </span>
                    <img src={copy} className='w-[14px] h-[14px]' />
                  </div>
                </TableCell>

                <TableCell sx={datastyle}>
                  <MoreDropDown />
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
