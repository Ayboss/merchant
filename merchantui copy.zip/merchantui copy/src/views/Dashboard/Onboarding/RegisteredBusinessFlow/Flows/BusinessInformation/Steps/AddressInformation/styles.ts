import tw from 'tailwind-styled-components';

export const AddressInformationContainer = tw.div``;
export const AddressInformationForm = tw.form``;
