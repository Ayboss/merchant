import tw from 'tailwind-styled-components';

export const BasicInformationContainer = tw.div``;
export const Title = tw.h2`
text-[16px]
text-[#333333]
font-semibold
`;

export const BasicInformationForm = tw.form``;
