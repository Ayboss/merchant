import React from 'react';

export const Others = () => {
  return <div>Others</div>;
};

export default Others;
