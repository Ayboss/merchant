import tw from 'tailwind-styled-components';

export const LogoInformationContainer = tw.div``;
export const LogoInformationForm = tw.form``;
