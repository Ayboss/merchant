import tw from 'tailwind-styled-components';

export const SocialInformationContainer = tw.div``;

export const SocialInformationForm = tw.form``;

export const Container = tw.div``;
export const FlexWrapper = tw.div`
flex
gap-8
`;
