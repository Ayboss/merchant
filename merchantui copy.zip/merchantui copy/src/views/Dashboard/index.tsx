import React from 'react';
import { Outlet } from 'react-router-dom';
import { DashboardLayout } from '../../layouts';
import { useProfileQuery } from '../../services/hooks/useGetProfileQuery';
import { popuptype, usePopupContext } from '../../context/PopupContext';
import { PaymentPopup } from './Payouts/PaymentPopup';
import { InvoiceCreatePopup } from './Invoices/InvoiceCreatePopup';
import { PaymentLinkCreatePopup } from './PaymentLink/PaymentLinkCreatePopup';

const MerchantsDashboard = () => {
  useProfileQuery();
  const { setShowInitiatePopup, showInitiatePopup } = usePopupContext();
  console.log(showInitiatePopup);
  return (
    <DashboardLayout>
      <Outlet />
      {showInitiatePopup === popuptype.PAYOUTPOPUP && (
        <PaymentPopup onClose={() => setShowInitiatePopup(null)} />
      )}
      {showInitiatePopup === popuptype.INVOICEPOPUP && (
        <InvoiceCreatePopup onClose={() => setShowInitiatePopup(null)} />
      )}
      {showInitiatePopup === popuptype.PAYMENTLINKPOPUP && (
        <PaymentLinkCreatePopup onClose={() => setShowInitiatePopup(null)} />
      )}
    </DashboardLayout>
  );
};

export default MerchantsDashboard;
