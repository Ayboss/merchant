import React, { useState } from 'react';
import { PayonusIcon } from '../../components/PayonusIcon';
import Searchinput from '../../components/SearchInput';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBell, faEnvelope } from '@fortawesome/free-regular-svg-icons';
import profile from '../../assets/img/manavatar.png';

import CustomSwitch from '../../components/CustomSwitch';
export const TopBar = () => {
  const [checked, setchecked] = useState(false);
  return (
    <div className='w-full bg-white px-[44px] py-[15px] shadow-[0px_1px_0px_0px_rgba(18_32_59_0.09)] border-solid border-b border-[#E4E4E7] h-[60px] flex items-center '>
      <PayonusIcon className=' cursor-pointer' isDark />
      <Searchinput
        name='search'
        placeholder='Type to search'
        className='flex-1 ml-[51px] mr-[53px] h-[40px]'
      />
      <div className='flex gap-2 items-center border   border-[#B8BCCA] rounded-full py-[8px] px-[5px] mr-[40px]'>
        <span className='text-[10px] text-[#B8BCCA] font-semibold'>TEST MODE OFF</span>
        <CustomSwitch />
        {/* <Switch onChange={() => setchecked(!checked)} width={34} height={21} checked={checked} /> */}
      </div>
      <div className='relative mr-[30px]'>
        <span className='text-white grid place-content-center -top-[10px] -right-[10px] bg-[#6231F4] w-[20px] h-[20px] text-[11px] p-1 absolute rounded-full'>
          3
        </span>
        <FontAwesomeIcon icon={faEnvelope} />
      </div>
      <div className='relative mr-[25px]'>
        <FontAwesomeIcon icon={faBell} />
      </div>
      <img src={profile} className='w-[30px] h-[30px] rounded-full object-cover' />
    </div>
  );
};
