import tw from 'tailwind-styled-components';

export const DashboardLayoutContainer = tw.div`
h-screen
width-full
min-h-full
flex
fade-in
`;
