import React, { Dispatch, PropsWithChildren, SetStateAction, createContext, useState } from 'react';

export const popuptype = {
  INVOICEPOPUP: 'INVOICEPOPUP',
  PAYOUTPOPUP: 'PAYOUTPOPUP',
  PAYMENTLINKPOPUP: 'PAYMENTLINKPOPUP'
};

export type PopupContextType = {
  setShowInitiatePopup: Dispatch<SetStateAction<string | null>>;
  showInitiatePopup: string | null;
};

const PopupContext = createContext<PopupContextType>({} as PopupContextType);

export const usePopupContext = () => React.useContext(PopupContext);

export const PopupContextProvider: React.FC<PropsWithChildren> = ({ children }) => {
  const [showInitiatePopup, setShowInitiatePopup] = useState<string | null>(null);

  return (
    <PopupContext.Provider value={{ showInitiatePopup, setShowInitiatePopup }}>
      {children}
    </PopupContext.Provider>
  );
};

export default PopupContext;
