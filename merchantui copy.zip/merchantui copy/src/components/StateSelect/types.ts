export type StateSelectProps = {
  label?: string;
  value?: string;
  country: any;
  placeholder: string;
  onChange?: (e: any) => void;
};
