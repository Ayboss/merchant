export interface SelectButtonProps {
  title: string;
  subtitle: string;
  onSelect: () => void;
  selectBtnIcon: string;
  activeButton: string;
}
