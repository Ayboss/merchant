export interface AuthHeaderProps {
  ctaUrl: string;
}
