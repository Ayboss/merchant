import React from 'react';
import { PaginationProps } from 'rc-pagination';
import 'rc-pagination/assets/index.css';
import './styles.css';

export const Paginator: React.FC<PaginationProps> = () => {
  return (
    <div className='w-full flex border-t justify-between items-center pt-[20px] px-[25px]'>
      <div className='text-[#344054] text-[14px] font-medium'>Page 1 of 10</div>
      <div className='flex items-center gap-3'>
        <button className='border-[#EAECF0] border px-[14px] py-[8px] rounded-lg text-[#444444] text-[14px]'>
          Previous
        </button>
        <button className='border-[#EAECF0] border px-[14px] py-[8px] rounded-lg text-[#444444] text-[14px]'>
          Next
        </button>
      </div>
    </div>
  );
};
