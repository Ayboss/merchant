import React from 'react';

import { AuthFooterContainer } from './styles';

export const AuthFooter = () => {
  return <AuthFooterContainer />;
};

export default AuthFooter;
