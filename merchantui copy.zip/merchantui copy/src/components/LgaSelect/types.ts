export type LgaSelectProps = {
  label?: string;
  value?: string;
  country: string;
  state: string;
  placeholder: string;
  onChange?: (e: any) => void;
};
