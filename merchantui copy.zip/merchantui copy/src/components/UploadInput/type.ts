export interface UploadInputProp {
  label?: string;
  name?: string;
}
