export interface NavButtonProps {
  onClick: () => void;
  name: string;
  activeNav: string;
}
