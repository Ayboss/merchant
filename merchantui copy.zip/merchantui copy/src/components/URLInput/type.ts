export interface URLInputProps {
  label?: string;
  name?: string;
  icon?: any;
  placeholder?: string;
}
