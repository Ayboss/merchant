import React from 'react';
import { CardType } from './type';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowDown, faArrowUp } from '@fortawesome/free-solid-svg-icons';

export const Card: React.FC<CardType> = ({ title, amount, rate }) => {
  return (
    <div className=' rounded-[10px] w-full h-[100px] p-[15px] px-[22px] flex flex-col gap-5 justify-start bg-white border-solid border-[1px] border-gray-200'>
      <span className=' text-[#6F7482] font-medium tracking-[1px] uppercase text-[11px]'>
        {title}
      </span>
      <div className='flex justify-between items-center'>
        <h4 className=' text-[21px] text-[#444]  font-bold'>{amount}</h4>
        {rate &&
          (rate[0] === '-' ? (
            <span className='text-[#EF4444] font-medium text-[13px] '>
              - {rate.substring(1)} <FontAwesomeIcon icon={faArrowDown} color='#EF4444' />
            </span>
          ) : (
            <span className='text-[#22C55E] font-medium text-[13px] '>
              + {rate.substring(1)} <FontAwesomeIcon icon={faArrowUp} color='#22C55E' />
            </span>
          ))}
      </div>
    </div>
  );
};
