export interface CardType {
  title: string;
  amount: string | number;
  rate?: string;
}
