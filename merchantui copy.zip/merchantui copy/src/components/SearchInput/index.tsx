import React, { forwardRef, useState } from 'react';
import { clsx } from 'clsx';
import { faEye, faEyeSlash, faSearch } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { FormGroup, Input } from './styles';
import { CustomInputProps } from './types';

export const Searchinput: React.FC<CustomInputProps> = forwardRef((props, ref) => {
  const { type = 'text', placeholder, className, errorText, InputClassName, ...rest } = props;

  const [inputType, setInputType] = useState<string>(type);

  const passToggle = () => {
    setInputType(inputType === 'password' ? 'text' : 'password');
  };

  const icon = inputType === 'password' ? faEyeSlash : faEye;

  return (
    <FormGroup
      className={clsx(
        'flex items-center border-[#E4E4E7] p-[6px] pl-4 gap-[10px] border-[1px]  rounded',
        className
      )}
    >
      <FontAwesomeIcon icon={faSearch} color='#A1A1AA' width={18} height={18} />
      <Input
        className={clsx(
          ' placeholder:text-[#A1A1AA] placeholder:text-[14px] placeholder:tracking-[0.14px] w-full  text-[#3B4256] bg-white text-[14px] leading-[17px] font-normal  focus:outline-[#6231F4]',
          InputClassName
        )}
        type={inputType}
        placeholder={placeholder}
        /* @ts-ignore no overload matches for the ref */
        ref={ref}
        {...rest}
      />
      {type === 'password' && (
        <FontAwesomeIcon
          className='absolute cursor-pointer right-3 bottom-[25%]'
          onClick={passToggle}
          icon={icon}
          style={{ color: '#b8bcca' }}
        />
      )}
      {errorText && (
        <span className='text-[#F04438] absolute bottom-[-20px] text-[12px] font-normal'>
          {errorText}
        </span>
      )}
    </FormGroup>
  );
});

export default Searchinput;
