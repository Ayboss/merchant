import tw from 'tailwind-styled-components';

export const FormGroup = tw.div`
    
`;

export const InputLabel = tw.label`

`;

export const Input = tw.input`
`;
