import { faAngleRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { Link } from 'react-router-dom';

function Navigation({ paths }: { paths: { title: string; link: string }[] }) {
  return (
    <>
      {/* LINK NAVIGATION */}
      <div className='flex items-center gap-4 mb-[30px]'>
        <Link to={'/'}>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            width='16'
            height='16'
            fill='#000000'
            viewBox='0 0 256 256'
          >
            <path d='M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z'></path>
          </svg>
        </Link>
        {paths.map((val, i) => {
          if (i === paths.length - 1) {
            return (
              <>
                <span>
                  <FontAwesomeIcon icon={faAngleRight} color='#A1A1AA' />
                </span>
                <Link className='text-[#A1A1AA] text-[14px]' to={val.link}>
                  {val.title}
                </Link>
              </>
            );
          }
          return (
            <>
              <span>
                <FontAwesomeIcon icon={faAngleRight} color='#A1A1AA' />
              </span>
              <Link className='text-[#444444] text-[14px]' to={val.link}>
                {val.title}
              </Link>
            </>
          );
        })}
      </div>
    </>
  );
}

export default Navigation;
