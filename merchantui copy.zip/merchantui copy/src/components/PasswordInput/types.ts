export type PasswrodInputProps = {
  label: string;
  name: string;
  placeholder: string;
  className?: string;
  ref?: any;
};
